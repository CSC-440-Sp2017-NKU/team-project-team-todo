Rails.application.routes.draw do
  
  
  resources :questions do
    resources :answers, :only => [:create]
  end
  resources :courses do
    resources :questions, :only => [:create, :destroy]
  end
  namespace :admin do
    DashboardManifest::DASHBOARDS.each do |dashboard_resource|
      resources dashboard_resource
    end
    
    root controller: DashboardManifest::ROOT_DASHBOARD, action: :index
    
  end

  root to: 'visitors#index'
  devise_for :users
  resources :users
  resources :courses
  devise_scope :user do
    get '/users/sign_out' => 'devise/sessions#destroy'
  end
  resources :answers
  
  
end
