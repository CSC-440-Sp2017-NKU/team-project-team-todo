class DashboardManifest
    DASHBOARDS = [
        :users,
        :courses,
        :questions
    ]
        
    ROOT_DASHBOARD = DASHBOARDS.first
end