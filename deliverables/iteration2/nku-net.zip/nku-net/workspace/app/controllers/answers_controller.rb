class AnswersController < ApplicationController
    before_action :authenticate_user!
    before_action :admin_only, only:[:destroy, :update]
    def index
      @answer = Answer.all
    end
    
    def create
        @question = Question.find(params[:question_id])
        @answer = @question.answers.build(answers_params)
        if @answer.save
            redirect_to @question, notice: "Answer was successfully created."
        else
            redirect_to @question, alert: "Error creating answer. " + @answer.errors.full_messages.to_sentence
        end
    end  
    
    # DELETE /answers/1
    # DELETE /answerss/1.json
    def destroy
        answer = Answer.find(params[:id])
        answer.destroy
        redirect_to questions_url, :notice => "Answer was successfully deleted."
        
    end
    
    
    
private

    def admin_only
      unless current_user.admin?
        redirect_to questions_url, :alert => "Only Admin can remove answers."
      end
    end
    
    def answers_params
        params.require(:answer).permit(:user_id, :body)
    end
end
