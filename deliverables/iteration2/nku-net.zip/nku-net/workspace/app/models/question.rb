class Question < ActiveRecord::Base
    belongs_to :user
    belongs_to :course
    has_many :answers
    validates :title, :presence => true
    validates :body, :presence => true
    validates :course, :presence => true
    validates :user, :presence => true
end
