FactoryGirl.define do
  factory :question do
    title "MyString"
    body "MyText"
    course ""
    user ""
  end
end
