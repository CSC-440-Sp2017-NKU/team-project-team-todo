FactoryGirl.define do
  factory :course do
    number "MyString"
    name "MyString"
    user ""
  end
end
