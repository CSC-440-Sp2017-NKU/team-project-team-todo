module CoursesHelper
    def courses_for_select
     Course.all.collect { |c| [c.number, c.id] }
    end
    def import
        
    end
end
