module QuestionsHelper
    def questions_for_select
     Question.all.collect { |q| [q.number, q.id] }
    end
end
