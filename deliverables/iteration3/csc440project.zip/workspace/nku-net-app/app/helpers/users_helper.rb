module UsersHelper
    def users_for_select
     User.all.collect { |u| [u.number, u.id] }
    end
end