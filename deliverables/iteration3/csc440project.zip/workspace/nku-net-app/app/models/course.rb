class Course < ActiveRecord::Base
    has_many :questions
    has_many :users
    belongs_to :user
    validates :number, :presence => true
    validates :name, :presence => true
end
