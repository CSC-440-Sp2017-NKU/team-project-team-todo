class User < ActiveRecord::Base
  has_many :courses
  has_many :questions
  has_many :answers    
  validates :name, :presence => true
  validates :email, :presence => true
  validates :password, :presence => true
  
  enum role: [:user, :vip, :admin]
  after_initialize :set_default_role, :if => :new_record?

  def set_default_role
    self.role ||= :user
  end

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable, :confirmable,
         :recoverable, :rememberable, :trackable, :validatable
end
