class VisitorsController < ApplicationController
end
